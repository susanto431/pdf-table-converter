import pdfplumber
import pandas as pd
import os
import re
from docx import Document
from typing import List, Tuple, Optional, Dict, Any, Union


class PDFProcessor:
    """
    A class to process PDF files, extract tables, and fix broken text.
    """
    
    def __init__(self, pdf_file: str, start_page: int = 1, end_page: Optional[int] = None):
        """
        Initialize the PDF processor.
        
        Args:
            pdf_file: Path to the PDF file
            start_page: First page to process (1-indexed)
            end_page: Last page to process (1-indexed, None means process until the end)
        """
        self.pdf_file = pdf_file
        self.start_page = max(1, start_page)  # Ensure start_page is at least 1
        self.end_page = end_page
        self.extracted_data = []
        self.total_pages = 0
        
    def extract_tables(self) -> List[List[Any]]:
        """
        Extract tables from the PDF file within the specified page range.
        
        Returns:
            List of rows extracted from tables
        """
        all_rows = []
        
        with pdfplumber.open(self.pdf_file) as pdf:
            self.total_pages = len(pdf.pages)
            
            # Adjust end_page if not specified or exceeds total pages
            if self.end_page is None or self.end_page > self.total_pages:
                self.end_page = self.total_pages
                
            # Convert to 0-indexed for pdfplumber
            start_idx = self.start_page - 1
            end_idx = self.end_page
            
            for i in range(start_idx, end_idx):
                page = pdf.pages[i]
                tables = page.extract_tables()
                
                for table in tables:
                    for row in table:
                        # Only add rows that have at least one non-empty cell
                        if any(cell and str(cell).strip() for cell in row):
                            all_rows.append(row)
        
        self.extracted_data = all_rows
        return all_rows
    
    def fix_broken_text(self) -> List[List[Any]]:
        """
        Fix broken text in table cells by joining sentences split across cells.
        
        Returns:
            List of rows with fixed text
        """
        if not self.extracted_data:
            return []
            
        fixed_data = []
        
        for row in self.extracted_data:
            fixed_row = []
            for cell in row:
                if cell is not None:
                    # Convert to string and fix common issues
                    cell_text = str(cell)
                    
                    # Remove excessive whitespace
                    cell_text = re.sub(r'\s+', ' ', cell_text)
                    
                    # Fix broken sentences (ending without punctuation and next line not starting with capital)
                    cell_text = re.sub(r'(\w)\s*\n\s*(\w)', r'\1 \2', cell_text)
                    
                    # Preserve paragraph breaks (line breaks after punctuation or before capital letters)
                    cell_text = re.sub(r'([.!?])\s*\n\s*([A-Z])', r'\1\n\2', cell_text)
                    
                    fixed_row.append(cell_text.strip())
                else:
                    fixed_row.append("")
            fixed_data.append(fixed_row)
            
        return fixed_data
    
    def save_to_excel(self, output_file: str, column_names: Optional[List[str]] = None) -> str:
        """
        Save the extracted data to an Excel file.
        
        Args:
            output_file: Path to save the Excel file
            column_names: Optional list of column names
            
        Returns:
            Path to the saved file
        """
        if not self.extracted_data:
            raise ValueError("No data to save. Run extract_tables() first.")
            
        # Fix broken text
        fixed_data = self.fix_broken_text()
        
        # Create DataFrame
        df = pd.DataFrame(fixed_data)
        
        # Set column names if provided and matching
        if column_names and len(column_names) == df.shape[1]:
            df.columns = column_names
            
        # Save to Excel
        df.to_excel(output_file, index=False)
        return output_file
    
    def save_to_word(self, output_file: str, column_names: Optional[List[str]] = None) -> str:
        """
        Save the extracted data to a Word document.
        
        Args:
            output_file: Path to save the Word file
            column_names: Optional list of column names
            
        Returns:
            Path to the saved file
        """
        if not self.extracted_data:
            raise ValueError("No data to save. Run extract_tables() first.")
            
        # Fix broken text
        fixed_data = self.fix_broken_text()
        
        # Create Word document
        doc = Document()
        
        # Add title
        doc.add_heading(f"Extracted Tables from {os.path.basename(self.pdf_file)}", level=1)
        
        # Create table
        if fixed_data:
            table = doc.add_table(rows=1, cols=len(fixed_data[0]))
            table.style = 'Table Grid'
            
            # Add header row if column names provided
            header_row = table.rows[0].cells
            if column_names and len(column_names) == len(fixed_data[0]):
                for i, name in enumerate(column_names):
                    header_row[i].text = name
            else:
                # Use first row as header if no column names provided
                for i, cell_text in enumerate(fixed_data[0]):
                    header_row[i].text = cell_text
                fixed_data = fixed_data[1:]
            
            # Add data rows
            for row_data in fixed_data:
                row_cells = table.add_row().cells
                for i, cell_text in enumerate(row_data):
                    if i < len(row_cells):  # Ensure we don't exceed the number of cells
                        row_cells[i].text = str(cell_text)
        
        # Save document
        doc.save(output_file)
        return output_file
    
    def get_preview(self, num_rows: int = 5) -> List[List[Any]]:
        """
        Get a preview of the extracted data.
        
        Args:
            num_rows: Number of rows to preview
            
        Returns:
            List of preview rows
        """
        if not self.extracted_data:
            return []
            
        # Fix broken text for preview
        fixed_data = self.fix_broken_text()
        
        # Return first n rows
        return fixed_data[:min(num_rows, len(fixed_data))]
