import streamlit as st
import os
import tempfile
import pandas as pd
import base64
from pdf_processor import PDFProcessor
from typing import Tuple, Optional, Dict, Any, List

# Set page configuration
st.set_page_config(
    page_title="PDF Table Extractor",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better UI
st.markdown("""
<style>
    .main {
        padding: 2rem;
    }
    .stButton button {
        width: 100%;
        border-radius: 5px;
        height: 3em;
        font-weight: bold;
    }
    .upload-section {
        border: 2px dashed #4e8df5;
        border-radius: 10px;
        padding: 2rem;
        text-align: center;
        margin-bottom: 2rem;
    }
    .preview-section {
        margin-top: 2rem;
        padding: 1rem;
        border: 1px solid #e0e0e0;
        border-radius: 5px;
    }
    h1, h2, h3 {
        color: #1e3d59;
    }
</style>
""", unsafe_allow_html=True)

def get_download_link(file_path: str, link_text: str) -> str:
    """
    Generate a download link for a file.
    
    Args:
        file_path: Path to the file to download
        link_text: Text to display for the download link
        
    Returns:
        HTML string with the download link
    """
    with open(file_path, "rb") as f:
        data = f.read()
    b64 = base64.b64encode(data).decode()
    file_name = os.path.basename(file_path)
    mime_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" if file_path.endswith(".xlsx") else "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    href = f'<a href="data:{mime_type};base64,{b64}" download="{file_name}">{link_text}</a>'
    return href

def process_pdf(pdf_path: str, start_page: int, end_page: Optional[int], output_format: str, output_filename: str) -> Tuple[str, List[List[Any]]]:
    """
    Process the PDF file and save to the selected format.
    
    Args:
        pdf_path: Path to the PDF file
        start_page: First page to process
        end_page: Last page to process (None for all pages)
        output_format: Format to save the output (excel or word)
        output_filename: Name for the output file
        
    Returns:
        Tuple of (output file path, preview data)
    """
    # Create temporary directory for output
    temp_dir = tempfile.mkdtemp()
    
    # Determine output file extension
    ext = ".xlsx" if output_format == "excel" else ".docx"
    
    # Create output file path
    if not output_filename:
        # Use input filename if no custom name provided
        base_name = os.path.splitext(os.path.basename(pdf_path))[0]
        output_filename = f"{base_name}{ext}"
    elif not output_filename.endswith(ext):
        # Add extension if not present
        output_filename = f"{output_filename}{ext}"
    
    output_path = os.path.join(temp_dir, output_filename)
    
    # Process PDF
    processor = PDFProcessor(pdf_path, start_page, end_page)
    processor.extract_tables()
    
    # Get preview data
    preview_data = processor.get_preview(5)
    
    # Save to selected format
    if output_format == "excel":
        processor.save_to_excel(output_path)
    else:
        processor.save_to_word(output_path)
    
    return output_path, preview_data

def main():
    """Main application function."""
    st.title("📊 PDF Table Extractor")
    st.markdown("Upload a PDF file to extract tables and convert to Excel or Word format.")
    
    # File upload section
    st.markdown('<div class="upload-section">', unsafe_allow_html=True)
    st.subheader("1. Upload PDF File")
    uploaded_file = st.file_uploader("Drag and drop or click to upload", type=["pdf"], key="pdf_uploader")
    st.markdown('</div>', unsafe_allow_html=True)
    
    if uploaded_file is not None:
        # Save uploaded file to temp location
        temp_pdf = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf")
        temp_pdf.write(uploaded_file.getvalue())
        pdf_path = temp_pdf.name
        temp_pdf.close()
        
        # Display PDF info
        st.success(f"✅ Uploaded: {uploaded_file.name}")
        
        # Configuration section
        st.subheader("2. Configure Extraction")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Page range selection
            st.markdown("##### Page Range")
            start_page = st.number_input("Start Page", min_value=1, value=1, step=1)
            end_page_option = st.radio("End Page", ["All Pages", "Specific Page"])
            
            if end_page_option == "Specific Page":
                end_page = st.number_input("End Page Number", min_value=start_page, value=start_page, step=1)
            else:
                end_page = None
        
        with col2:
            # Output format selection
            st.markdown("##### Output Format")
            output_format = st.selectbox("Select Format", ["excel", "word"], index=0)
            
            # Custom filename
            st.markdown("##### Output Filename")
            use_custom_name = st.checkbox("Use custom filename")
            
            if use_custom_name:
                output_filename = st.text_input("Enter filename (without extension)")
            else:
                output_filename = os.path.splitext(uploaded_file.name)[0]
        
        # Process button
        if st.button("Extract Tables", key="extract_button"):
            with st.spinner("Processing PDF..."):
                try:
                    output_path, preview_data = process_pdf(
                        pdf_path, 
                        start_page, 
                        end_page, 
                        output_format,
                        output_filename
                    )
                    
                    # Show preview
                    st.subheader("3. Preview (First 5 Rows)")
                    if preview_data:
                        st.markdown('<div class="preview-section">', unsafe_allow_html=True)
                        preview_df = pd.DataFrame(preview_data)
                        st.dataframe(preview_df, use_container_width=True)
                        st.markdown('</div>', unsafe_allow_html=True)
                    else:
                        st.warning("No tables found in the selected pages.")
                    
                    # Download section
                    st.subheader("4. Download Result")
                    ext = ".xlsx" if output_format == "excel" else ".docx"
                    download_filename = f"{output_filename}{ext}"
                    
                    st.markdown(
                        get_download_link(
                            output_path, 
                            f"📥 Download {download_filename}"
                        ),
                        unsafe_allow_html=True
                    )
                    
                except Exception as e:
                    st.error(f"Error processing PDF: {str(e)}")
                finally:
                    # Clean up temp files
                    try:
                        os.unlink(pdf_path)
                    except:
                        pass
        
        # Reset button
        if st.button("Reset All", key="reset_button"):
            st.experimental_rerun()

if __name__ == "__main__":
    main()
