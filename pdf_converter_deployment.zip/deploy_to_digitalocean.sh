#!/bin/bash

# Script untuk men-deploy aplikasi PDF Converter ke Digital Ocean Droplet
# Dibuat oleh Augment Agent

set -e  # Exit jika ada error

# Warna untuk output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Fungsi untuk menampilkan pesan
print_message() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Konfigurasi
APP_NAME="pdf_converter"
APP_DIR="/opt/${APP_NAME}"
PORT=8501  # Port default Streamlit
SERVICE_NAME="${APP_NAME}"
PYTHON_VERSION="3.9"  # Sesuaikan dengan versi Python yang digunakan

# Cek apakah script dijalankan sebagai root
if [ "$EUID" -ne 0 ]; then
    print_error "Script ini harus dijalankan sebagai root atau dengan sudo"
    exit 1
fi

# Cek apakah direktori aplikasi sudah ada
if [ -d "$APP_DIR" ]; then
    print_warning "Direktori $APP_DIR sudah ada. Aplikasi mungkin sudah terinstal."
    read -p "Apakah Anda ingin melanjutkan dan menimpa instalasi yang ada? (y/n): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        print_message "Instalasi dibatalkan."
        exit 0
    fi
fi

# Buat direktori aplikasi jika belum ada
print_message "Membuat direktori aplikasi di $APP_DIR..."
mkdir -p "$APP_DIR"

# Salin file aplikasi ke direktori tujuan
print_message "Menyalin file aplikasi..."
cp -f app.py "$APP_DIR/"
cp -f pdf_processor.py "$APP_DIR/"
cp -f requirements.txt "$APP_DIR/"

# Cek apakah Python tersedia
if ! command -v python$PYTHON_VERSION &> /dev/null; then
    print_warning "Python $PYTHON_VERSION tidak ditemukan. Mencoba menggunakan Python default..."
    if ! command -v python3 &> /dev/null; then
        print_error "Python 3 tidak ditemukan. Silakan install Python 3 terlebih dahulu."
        exit 1
    fi
    PYTHON_CMD="python3"
else
    PYTHON_CMD="python$PYTHON_VERSION"
fi

# Cek apakah pip tersedia
if ! command -v pip3 &> /dev/null; then
    print_error "pip3 tidak ditemukan. Silakan install pip3 terlebih dahulu."
    exit 1
fi

# Buat virtual environment
print_message "Membuat virtual environment..."
cd "$APP_DIR"
$PYTHON_CMD -m venv venv

# Aktifkan virtual environment dan install dependensi
print_message "Menginstall dependensi..."
source "$APP_DIR/venv/bin/activate"
pip install --upgrade pip
pip install -r requirements.txt

# Buat file konfigurasi Streamlit untuk akses publik
print_message "Membuat konfigurasi Streamlit..."
mkdir -p "$APP_DIR/.streamlit"
cat > "$APP_DIR/.streamlit/config.toml" << EOF
[server]
headless = true
enableCORS = false
enableXsrfProtection = true
port = $PORT

[browser]
serverAddress = "0.0.0.0"
serverPort = $PORT
EOF

# Buat systemd service file
print_message "Membuat systemd service..."
cat > "/etc/systemd/system/${SERVICE_NAME}.service" << EOF
[Unit]
Description=PDF Converter Streamlit Application
After=network.target

[Service]
User=root
WorkingDirectory=${APP_DIR}
ExecStart=${APP_DIR}/venv/bin/streamlit run ${APP_DIR}/app.py
Restart=always
RestartSec=5
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=${SERVICE_NAME}
Environment="LC_ALL=C.UTF-8"
Environment="LANG=C.UTF-8"

[Install]
WantedBy=multi-user.target
EOF

# Reload systemd, enable dan start service
print_message "Memulai service..."
systemctl daemon-reload
systemctl enable ${SERVICE_NAME}.service
systemctl start ${SERVICE_NAME}.service

# Cek status service
if systemctl is-active --quiet ${SERVICE_NAME}.service; then
    print_message "Service ${SERVICE_NAME} berhasil dijalankan!"
else
    print_error "Service ${SERVICE_NAME} gagal dijalankan. Cek log dengan: journalctl -u ${SERVICE_NAME}.service"
    exit 1
fi

# Tampilkan informasi akses
IP_ADDRESS=$(hostname -I | awk '{print $1}')
print_message "Aplikasi PDF Converter berhasil di-deploy!"
print_message "Anda dapat mengakses aplikasi di: http://${IP_ADDRESS}:${PORT}"
print_message "Atau gunakan IP publik droplet Anda: http://PUBLIC_IP:${PORT}"
print_message "Pastikan port ${PORT} sudah dibuka di firewall Digital Ocean Anda"

# Petunjuk tambahan
cat << EOF

${YELLOW}=== PETUNJUK TAMBAHAN ===${NC}

1. Untuk membuka port di firewall Digital Ocean:
   - Buka dashboard Digital Ocean
   - Pilih droplet Anda
   - Pilih tab "Networking"
   - Di bagian "Firewall", klik "Edit" dan tambahkan rule untuk port ${PORT}

2. Untuk melihat log aplikasi:
   journalctl -u ${SERVICE_NAME}.service

3. Untuk menghentikan aplikasi:
   sudo systemctl stop ${SERVICE_NAME}.service

4. Untuk memulai ulang aplikasi:
   sudo systemctl restart ${SERVICE_NAME}.service

5. Untuk melihat status aplikasi:
   sudo systemctl status ${SERVICE_NAME}.service

EOF
