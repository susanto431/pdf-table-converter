# PDF Converter

Aplikasi untuk mengkonversi tabel dari file PDF ke format Excel atau Word dengan fitur perbaikan teks.

## Fitur

- Upload PDF apa saja
- Pilih format output (Excel atau Word)
- Tentukan halaman awal dan akhir
- Perbaikan teks yang pecah karena line break
- Penamaan file output otomatis
- Preview hasil sebelum download
- Antarmuka pengguna yang ramah

## Cara Deployment ke Digital Ocean

### Metode 1: Deployment Otomatis

1. **Upload file-file berikut ke droplet Digital Ocean Anda**:
   - `app.py`
   - `pdf_processor.py`
   - `requirements.txt`
   - `deploy_to_digitalocean.sh`

2. **Jalankan script deployment**:
   ```bash
   chmod +x deploy_to_digitalocean.sh
   sudo ./deploy_to_digitalocean.sh
   ```

3. **Buka port di firewall Digital Ocean**:
   - Buka dashboard Digital Ocean
   - Pilih droplet Anda
   - Pilih tab "Networking"
   - Di bagian "Firewall", klik "Edit" dan tambahkan rule untuk port 8501

4. **Akses aplikasi**:
   - Buka browser dan akses: `http://[IP_DROPLET]:8501`

### Metode 2: Deployment Manual

Jika Anda lebih suka melakukan deployment secara manual, ikuti langkah-langkah berikut:

1. **Buat direktori untuk aplikasi**:
   ```bash
   sudo mkdir -p /opt/pdf_converter
   ```

2. **Salin file aplikasi**:
   ```bash
   sudo cp app.py pdf_processor.py requirements.txt /opt/pdf_converter/
   ```

3. **Buat virtual environment**:
   ```bash
   cd /opt/pdf_converter
   sudo python3 -m venv venv
   ```

4. **Install dependensi**:
   ```bash
   sudo /opt/pdf_converter/venv/bin/pip install -r requirements.txt
   ```

5. **Buat konfigurasi Streamlit**:
   ```bash
   sudo mkdir -p /opt/pdf_converter/.streamlit
   sudo bash -c 'cat > /opt/pdf_converter/.streamlit/config.toml << EOF
   [server]
   headless = true
   enableCORS = false
   port = 8501

   [browser]
   serverAddress = "0.0.0.0"
   serverPort = 8501
   EOF'
   ```

6. **Buat systemd service**:
   ```bash
   sudo bash -c 'cat > /etc/systemd/system/pdf_converter.service << EOF
   [Unit]
   Description=PDF Converter Streamlit Application
   After=network.target

   [Service]
   User=root
   WorkingDirectory=/opt/pdf_converter
   ExecStart=/opt/pdf_converter/venv/bin/streamlit run /opt/pdf_converter/app.py
   Restart=always
   RestartSec=5
   StandardOutput=syslog
   StandardError=syslog
   SyslogIdentifier=pdf_converter
   Environment="LC_ALL=C.UTF-8"
   Environment="LANG=C.UTF-8"

   [Install]
   WantedBy=multi-user.target
   EOF'
   ```

7. **Aktifkan dan jalankan service**:
   ```bash
   sudo systemctl daemon-reload
   sudo systemctl enable pdf_converter.service
   sudo systemctl start pdf_converter.service
   ```

8. **Periksa status service**:
   ```bash
   sudo systemctl status pdf_converter.service
   ```

## Perintah Berguna

- **Melihat log aplikasi**:
  ```bash
  sudo journalctl -u pdf_converter.service
  ```

- **Menghentikan aplikasi**:
  ```bash
  sudo systemctl stop pdf_converter.service
  ```

- **Memulai ulang aplikasi**:
  ```bash
  sudo systemctl restart pdf_converter.service
  ```

## Penggunaan Aplikasi

1. Buka aplikasi di browser: `http://[IP_DROPLET]:8501`
2. Upload file PDF
3. Tentukan halaman awal dan akhir
4. Pilih format output (Excel atau Word)
5. Klik "Extract Tables"
6. Preview hasil ekstraksi
7. Download hasil konversi

## Troubleshooting

- **Aplikasi tidak dapat diakses**:
  - Pastikan service berjalan: `sudo systemctl status pdf_converter.service`
  - Pastikan port 8501 terbuka di firewall
  - Periksa log untuk error: `sudo journalctl -u pdf_converter.service`

- **Error saat ekstraksi**:
  - Pastikan PDF memiliki tabel yang dapat dideteksi
  - Periksa log aplikasi untuk detail error
